baymax
======

Data Visualization Template Engine for Django/Flask
